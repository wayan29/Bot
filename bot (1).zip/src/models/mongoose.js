import { JSONPreset } from 'lowdb/node';
const defaultData = {
    User: [],
};
const db = await JSONPreset('User.json', defaultData)

// make a new user
// return {
//     chatId,
//     username,
//     isPremium: false,
// };
const createUser = (chatId, username) => {
    const data = {
        chatId,
        username,
        isPremium: false,
    };
    db.data.User.push(data);
    db.write();
}
// check if user is premium
// return false / true
const isPremium = (chatId) => {
    const user = db.data.User.find((user) => user.chatId === chatId);
    if (user) {
        return user.isPremium;
    }
    return false;
}
// set user to premium
// void 
const setPremium = (chatId) => {
    const user = db.data.User.find((user) => user.chatId === chatId);
    if (user) {
        user.isPremium = true;
        db.write();
    }
}

// buat function check apakah user ada / tidak 
const checkUser = (chatId) => {
    const user = db.data.User.find((user) => user.chatId === chatId);
    if (user) {
        return true;
    }
    return false;
}

// export 
export { createUser, isPremium, setPremium, checkUser, db as default };