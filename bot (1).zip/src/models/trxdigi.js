import { JSONPreset } from 'lowdb/node';

const defaultData = {
    digi: [],
};
const db = await JSONPreset('digi.json', defaultData);


// make new data
const createDigi = async (ref_id, customer_no, buyer_sku_code, message, status, rc, buyer_last_saldo, sn, price, tele, wa) => {
    const data = {
        ref_id,
        customer_no,
        buyer_sku_code,
        message,
        status,
        rc,
        buyer_last_saldo,
        sn,
        price,
        tele,
        wa
    };
    db.data.digi.push(data);
    await db.write();
}

// check by ref_id
const checkDigi = async (ref_id) => {
    await db.read();
    const digi = db.data.digi.find((tov) => tov.ref_id === ref_id);
    if (digi) {
        return digi;
    }
    return false;
}

// modif by ref_id
const modifDigi = async (ref_id, status, sn) => {
    const digi = db.data.digi.find((tov) => tov.ref_id === ref_id);
    if (digi) {
        digi.status = status;
        digi.sn = sn;
        await db.write();
    }
}

// get all data
const getAllDigi = async() => {
    db.read();
    return db.data.digi;
}

// export
export { createDigi, checkDigi, modifDigi, getAllDigi, db as default };