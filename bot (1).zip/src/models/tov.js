import { JSONPreset } from 'lowdb/node';

const defaultData = {
    tov: [],
};
const db = await JSONPreset('tov.json', defaultData);

// make new data 
const createTov = async (status, message, sn, ref_id, trx_id, produk, sisa_saldo, price) => {
    const data = {
        status,
        message,
        sn,
        ref_id,
        trx_id,
        produk,
        sisa_saldo,
        price
    };
    db.data.tov.push(data);
    await db.write();
}

// check by trx_id
const checkTov = (trx_id) => {
    const tov = db.data.tov.find((tov) => tov.trx_id === trx_id);
    if (tov) {
        // balikkan data
        return tov;
    }
    return false;
}

// modif by ref_id
const modifTov = async (ref_id, status, sn) => {
    const tov = db.data.tov.find((tov) => tov.ref_id === ref_id);
    if (tov) {
        tov.status = status;
        tov.sn = sn;
        await db.write();
    }
}

// get all data
const getAllTov = () => {
    return db.data.tov;
}

// export
export { createTov, checkTov, modifTov, getAllTov, db as default };