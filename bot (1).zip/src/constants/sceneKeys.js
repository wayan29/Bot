const SCENE_KEYS = {
    BOT: 'bot',
    CATEGORY: 'category',
    BRAND: 'brand',
    PRODUCT: 'product',
    PRICE: 'price',
    OPSI1: 'opsi1',
    OPSI2: 'opsi2',
};
export default SCENE_KEYS;
