import telegraf from "telegraf";
import dotenv from "dotenv";
import botMenu from "./scenes/botMenu.js";
import botJenis from "./scenes/botKategory.js";
import BotProduk from "./scenes/botBrand.js";
import BotProduct from "./scenes/botProduct.js";
import BotPrice from "./scenes/botPrice.js";
import OPSI1 from "./scenes/opsi1.js";
import OPSI2 from "./scenes/opsi2.js";
import SCENE_KEYS from "./constants/sceneKeys.js";
import pln from "./function/plncuy.js";
import checkOperator from "./middleware/Checkop.js";
import User, { setPremium, isPremium, createUser, checkUser } from "./models/mongoose.js";
// import mongoose from "mongoose";
import { checkStatus, GetAll } from "./middleware/CheckTOV.js";
import { getAllDigiflazz, checkDigiflazz } from "./middleware/Digiflazz.js";
const { Telegraf, session, Scenes } = telegraf;
dotenv.config();
// const dbURL = process.env.MONGO_URL;
// mongoose.connect(dbURL, { useNewUrlParser: true, useUnifiedTopology: true })
//     .then(() => console.log('Connected to MongoDB'))
//     .catch((err) => console.error('Error connecting to MongoDB:', err));
const listStage = [
    botMenu,
    botJenis,
    BotProduk,
    BotProduct,
    BotPrice,
    OPSI1,
    OPSI2
];
const bot = new Telegraf(process.env.TOKEN);
const stage = new Scenes.Stage(listStage);
bot.use(async (ctx, next) => {
    const chatId = ctx.message.chat.id;
    await User.read();
    if (isPremium(chatId)) {
        return next();
    } else {
        // jika user belum terdaftar buatkan user baru
        if (checkUser(chatId) == false) {
            createUser(chatId, ctx.message.from.username);
        }
        // console.log(isPremium(chatId))
        ctx.reply('Sepertinya Kita Temenan Aja');
    }
});
const checkPln = async (ctx, next) => {
    if (ctx.message.text.startsWith('/pln ')) {
        const noPelanggan = ctx.message.text.slice(5).trim();
        try {
            const data = await pln(noPelanggan);
            const message = `*${data.name}*\n` +
                `*No Meter*: ${data.meter_no}\n` +
                `*ID Pelanggan*: ${data.subscriber_id}\n` +
                `*Segment Power*: ${data.segment_power}\n`;
            ctx.reply(message, { parse_mode: 'Markdown' });
        }
        catch (error) {
            ctx.reply('No Pelanggan tidak ditemukan atau terjadi kesalahan dalam mengambil data.');
        }
    }
    else if (ctx.message.text === '/pln') {
        ctx.reply('Mohon masukkan nomor pelanggan setelah perintah /pln');
    }
    else {
        next();
    }
};
bot.use(checkStatus);
bot.use(checkDigiflazz);
bot.use(GetAll);
bot.use(getAllDigiflazz);
bot.use(checkPln);
bot.use(checkOperator);
bot.use(session());
bot.use(stage.middleware());
bot.command('start', (ctx) => ctx.scene.enter(SCENE_KEYS.BOT));
bot.on('text', (ctx) => {
    ctx.scene.enter(SCENE_KEYS.BOT);
});
if (process.env.NODE_ENV === 'production') {
    bot.launch({
        webhook: {
            domain: process.env.HEROKU_URL,
            port: process.env.PORT
        }
    });
}
else {
    bot.launch();
}
