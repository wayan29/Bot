import telegraf from "telegraf";
import SCENE_KEYS from "../constants/sceneKeys.js";
import { showKeyboardChunk } from "../function/keyboard.js";
import { getListProductDigi, checkSaldoDigi } from "../function/http.js";
import { getKategori, checkSaldo, numberWithCommas } from "../function/http_toko.js";
const botMenu = new telegraf.Scenes.BaseScene(SCENE_KEYS.CATEGORY);
botMenu.enter(async (ctx) => {
    const selectedBot = ctx.session.selectedBot;
    if (!selectedBot) {
        ctx.scene.enter(SCENE_KEYS.BOT);
        return;
    }
    const saldo = selectedBot === 'Digiflazz' ? await checkSaldoDigi() : await checkSaldo();
    const productList = selectedBot === 'Digiflazz' ? await getListProductDigi() : await getKategori();
    ctx.session.productList = productList;
    const list = `Silakan Pilih Kategori\n\n${productList.map((item, index) => `${index + 1}. ${selectedBot === 'Digiflazz' ? item : item.nama}`).join('\n')}`;
    ctx.reply(`Saldo Anda : RP ${numberWithCommas(saldo)}`);
    ctx.reply(list, showKeyboardChunk(['Back']));
});
botMenu.on('text', async (ctx) => {
    const selectedCategory = ctx.message.text;
    if (selectedCategory === 'Back') {
        ctx.scene.enter(SCENE_KEYS.BOT);
        return;
    }
    const selectedBot = ctx.session.selectedBot;
    const productList = ctx.session.productList;
    const selectedCategoryIndex = parseInt(selectedCategory) - 1;
    if (!isNaN(selectedCategoryIndex) && productList[selectedCategoryIndex]) {
        ctx.session.selectedCategory = productList[selectedCategoryIndex];
        ctx.scene.enter(SCENE_KEYS.BRAND);
    }
    else {
        ctx.reply('Maaf, Pilihan Belum tersedia');
    }
});
export default botMenu;
