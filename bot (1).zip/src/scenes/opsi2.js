import telegraf from "telegraf";
import SCENE_KEYS from "../constants/sceneKeys.js";
import { showKeyboardChunk } from "../function/keyboard.js";
import { createTrx, getRefId } from "../function/http_toko.js";
import tovDB, { createTov } from "../models/tov.js";
const botMenu = new telegraf.Scenes.BaseScene(SCENE_KEYS.OPSI2);
botMenu.enter(async (ctx) => {
    const BOT = ctx.session.selectedBot;
    if (BOT === 'TokoVoucher') {
        ctx.session.codeList = ctx.session.selectedProduct.code;
        ctx.reply('Silahkan Masukkan SERVER ID (OPSIONAL)', showKeyboardChunk(["Kosong", "Back"], 1));
    }
});
botMenu.on('text', async (ctx) => {
    const pesan = ctx.message.text;
    if (pesan == "Back") {
        ctx.scene.enter(SCENE_KEYS.PRICE);
    }
    else if (ctx.session.selectedBot === 'TokoVoucher') {
        const ref_id = await getRefId();
        const NomorTujuan = ctx.session.nomorTujuan;
        const codeList = ctx.session.codeList;
        const server_id = pesan === "Kosong" ? "" : pesan;
        const trx_id = await createTrx(ref_id, codeList, NomorTujuan, server_id);
        console.log(trx_id.status);
        if (['sukses', 'pending'].includes(trx_id.status)) {
            await createTov(trx_id.status, trx_id.message, trx_id.sn, trx_id.ref_id, trx_id.trx_id, trx_id.produk, trx_id.sisa_saldo, trx_id.price);
            // await newTokoV.save();
        }
        switch (trx_id.status) {
            case 'sukses':
                ctx.reply(`Transaksi Sukses, ID Transaksi : ${trx_id.trx_id}`);
                break;
            case 'pending':
                ctx.reply(`Transaksi Pending, ID Transaksi : ${trx_id.trx_id}`);
                break;
            case 'gagal':
                ctx.reply(`Transaksi Gagal, ID Transaksi : ${trx_id.trx_id}`);
                break;
            default:
                ctx.reply(`Error : ${trx_id.error_msg}`);
                break;
        }
        ctx.session = {};
        ctx.session.selectedBot = 'TokoVoucher';
        ctx.scene.enter(SCENE_KEYS.CATEGORY);
    }
});
export default botMenu;
