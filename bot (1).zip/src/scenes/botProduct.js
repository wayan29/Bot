import telegraf from "telegraf";
import SCENE_KEYS from "../constants/sceneKeys.js";
import { showKeyboardChunk } from "../function/keyboard.js";
import { getProductList } from "../function/http.js";
import { getJenis } from "../function/http_toko.js";
const botMenu = new telegraf.Scenes.BaseScene(SCENE_KEYS.PRODUCT);
botMenu.enter(async (ctx) => {
    const BOT = ctx.session.selectedBot;
    if (BOT === 'Digiflazz') {
        const { selectedCategory, selectedBrand } = ctx.session;
        const productList = await getProductList(selectedCategory, selectedBrand);
        ctx.session.productList = productList;
        const list = `----------- Silakan Pilih Product -----------\n` + productList.map((item, index) => `${index + 1}. ${item.product_name}`).join('\n');
        ctx.reply(list, showKeyboardChunk(['Back']));
    }
    if (BOT === 'TokoVoucher') {
        const { id } = ctx.session.selectedBrand;
        const listJenis = await getJenis(id);
        ctx.session.listJenis = listJenis;
        const list = `----------- Silakan Pilih Product -----------\n` + listJenis.map((item, index) => `${index + 1}. ${item.nama}`).join('\n');
        ctx.reply(list, showKeyboardChunk(['Back']));
    }
});
botMenu.on('text', (ctx) => {
    const text = ctx.message.text;
    if (text === "Back") {
        ctx.scene.enter(SCENE_KEYS.BRAND);
    }
    else {
        const BOT = ctx.session.selectedBot;
        const selectedProductIndex = parseInt(text) - 1;
        if (BOT === 'Digiflazz') {
            const productList = ctx.session.productList;
            if (!isNaN(selectedProductIndex) && productList[selectedProductIndex]) {
                ctx.session.selectedProduct = productList[selectedProductIndex];
                ctx.scene.enter(SCENE_KEYS.PRICE);
            }
            else {
                ctx.reply('Maaf, Pilihan Belum tersedia');
            }
        }
        else if (BOT === 'TokoVoucher') {
            const listJenis = ctx.session.listJenis;
            if (!isNaN(selectedProductIndex) && listJenis[selectedProductIndex]) {
                ctx.session.selectedProduct = listJenis[selectedProductIndex];
                ctx.session.MenuPrice = listJenis[selectedProductIndex];
                ctx.scene.enter(SCENE_KEYS.PRICE);
            }
            else {
                ctx.reply('Maaf, Pilihan Belum tersedia');
            }
        }
    }
});
export default botMenu;
