import telegraf from "telegraf";
import SCENE_KEYS from "../constants/sceneKeys.js";
import { showKeyboardChunk } from "../function/keyboard.js";
import { getListBrand } from "../function/http.js";
import { findIdByName, getOperatorByCategory } from "../function/http_toko.js";
let listBrand;
const botMenu = new telegraf.Scenes.BaseScene(SCENE_KEYS.BRAND);
botMenu.enter(async (ctx) => {
    // console.log("Masukk Scene Brand")
    const selectedCategory = ctx.session.selectedCategory;
    const BOT = ctx.session.selectedBot;
    if (BOT === 'Digiflazz') {
        try {
            listBrand = await getListBrand(selectedCategory);
            if (Array.isArray(listBrand) && listBrand.length > 0) {
                const list = "--------- Silakan Pilih Brand ---------\n\n" + listBrand.map((item, index) => `${index + 1}. ${item}`).join('\n');
                ctx.reply(list, showKeyboardChunk(['Back']));
            }
            else {
                ctx.reply('Maaf, daftar brand tidak tersedia.');
            }
        }
        catch (error) {
            console.error(error);
            ctx.reply('Terjadi kesalahan saat mengambil data brand.');
        }
    }
    else if (BOT === 'TokoVoucher') {
        const id_category = selectedCategory.id;
        try {
            listBrand = await getOperatorByCategory(id_category);
            if (Array.isArray(listBrand) && listBrand.length > 0) {
                const list = "--------- Silakan Pilih Brand ---------\n\n" + listBrand.map((item, index) => `${index + 1}. ${item.nama}`).join('\n');
                ctx.reply(list, showKeyboardChunk(['Back']));
            }
            else {
                ctx.reply('Maaf, daftar brand tidak tersedia.');
            }
        }
        catch (error) {
            console.error(error);
            ctx.reply('Terjadi kesalahan saat mengambil data brand.');
        }
    }
});
botMenu.on('text', (ctx) => {
    const text = ctx.message.text;
    if (text == "Back") {
        ctx.scene.enter(SCENE_KEYS.CATEGORY);
    }
    else {
        const BOT = ctx.session.selectedBot;
        if (BOT === 'Digiflazz') {
            if (!isNaN(text)) {
                if (listBrand[text - 1]) {
                    ctx.session.selectedBrand = listBrand[text - 1];
                    ctx.scene.enter(SCENE_KEYS.PRODUCT);
                }
                else {
                    ctx.reply('Maaf, Pilihan Belum tersedia');
                }
            }
            else {
                ctx.reply('Maaf, Pilihan Belum tersedia');
            }
        }
        else if (BOT === 'TokoVoucher') {
            if (!isNaN(text)) {
                if (listBrand[text - 1]) {
                    ctx.session.selectedBrand = listBrand[text - 1];
                    ctx.scene.enter(SCENE_KEYS.PRODUCT);
                }
                else {
                    ctx.reply('Maaf, Pilihan Belum tersedia');
                }
            }
        }
    }
});
export default botMenu;
