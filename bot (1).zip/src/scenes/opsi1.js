import telegraf from "telegraf";
import SCENE_KEYS from "../constants/sceneKeys.js";
import { showKeyboardChunk } from "../function/keyboard.js";
const botMenu = new telegraf.Scenes.BaseScene(SCENE_KEYS.OPSI1);
botMenu.enter(async (ctx) => {
    const selectedJenis = ctx.session.selectedProduct;
    const BOT = ctx.session.selectedBot;
    if (BOT === 'Digiflazz') {
    }
    if (BOT === 'TokoVoucher') {
        ctx.session.codeList = ctx.session.selectedProduct.code;
        const keyboardaja = showKeyboardChunk(["Back"]);
        ctx.replyWithHTML(`Kode : <code>${ctx.session.codeList}</code>\n` + `Product : <b>${ctx.session.selectedProduct.nama_produk}</b>\n` + `Harga : RP ${Number(ctx.session.selectedProduct.price).toLocaleString('en-US')}\n` + `Status : <b>${ctx.session.selectedProduct.status ? 'Tersedia' : 'Gangguan !!'}</b>`);
        ctx.reply('Silahkan Masukkan Nomor Tujuan', keyboardaja);
    }
});
botMenu.on('text', async (ctx) => {
    const pesan = ctx.message.text;
    if (pesan == "Back") {
        ctx.scene.enter(SCENE_KEYS.PRICE);
    }
    else {
        const BOT = ctx.session.selectedBot;
        if (BOT === 'Digiflazz') {
            ctx.scene.enter(SCENE_KEYS.CATEGORY);
        }
        if (BOT === 'TokoVoucher') {
            ctx.session.nomorTujuan = pesan;
            ctx.scene.enter(SCENE_KEYS.OPSI2);
        }
    }
});
export default botMenu;
