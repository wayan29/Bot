import telegraf from "telegraf";
import SCENE_KEYS from "../constants/sceneKeys.js";
import { showKeyboardChunk, splitList, formatCurrency } from "../function/keyboard.js";
import { getPrice, performTransaction } from "../function/http.js";
import { findIdJenisByName, getListJenis } from "../function/http_toko.js";
import digiDB, { createDigi } from "../models/trxdigi.js";
let List;
const botMenu = new telegraf.Scenes.BaseScene(SCENE_KEYS.PRICE);
botMenu.enter(async (ctx) => {
    let selectedProduct = ctx.session.selectedProduct;
    const BOT = ctx.session.selectedBot;
    if (BOT === 'Digiflazz') {
        List = selectedProduct;
        let text = `Detail Product ${selectedProduct.product_name} \n`;
        const price = List.price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
        text += `Harga : Rp. ${price} \n`;
        text += `SKU : ${List.buyer_sku_code} \n`;
        ctx.session.sku = List.buyer_sku_code;
        text += `Nama Penjual : ${List.seller_name} \n`;
        text += `Seller product status : ${List.seller_product_status ? 'AKTIF' : 'TIDAK AKTIF'} \n`;
        text += `Buyer product status : ${List.buyer_product_status ? 'AKTIF' : 'TIDAK AKTIF'} \n`;
        const refId = "REF" + new Date().toISOString().replace(/[^0-9]/g, "").substring(0, 14) + "WAYAN";
        ctx.session.refId = refId;
        text += `Ref ID : ${refId} \n`;
        ctx.reply(text);
        ctx.reply('Masukkan nomor pelanggan:', showKeyboardChunk(["Back"]));
    }
    if (BOT === 'TokoVoucher') {
        selectedProduct = ctx.session.MenuPrice;
        console.log(selectedProduct);
        const id_jenis = selectedProduct.id;
        console.log(id_jenis);
        const listJenis = await getListJenis(id_jenis);
        ctx.session.listJenis = listJenis;
        const chunkSize = 25;
        const chunks = splitList(listJenis, chunkSize);
        for (let i = 0; i < chunks.length; i++) {
            const listChunk = "Silakan Pilih Product\n\n" + chunks[i].map((item, index) => `${i * chunkSize + index + 1}. ${item.nama_produk} | ${formatCurrency(item.price)}`).join('\n');
            await ctx.reply(listChunk, showKeyboardChunk(['Back']));
        }
    }
});
botMenu.on('text', async (ctx) => {
    const pesan = ctx.message.text;
    if (pesan == "Back") {
        ctx.scene.enter(SCENE_KEYS.PRODUCT);
    }
    else {
        ctx.session.selectedProduct = pesan;
        const BOT = ctx.session.selectedBot;
        if (BOT === 'Digiflazz') {
            const proses = await performTransaction(ctx.session.refId, ctx.session.sku, ctx.message.text);
            let text = `Detail Transaksi \n`;
            if (proses.status == "Gagal") {
                text += `Status : ${proses.status} \n`;
                text += `Message : ${proses.message} \n`;
            }
            else {
                text += `Status : ${proses.status} \n`;
                text += `Message : ${proses.message} \n`;
                text += `Ref ID : ${proses.ref_id} \n`;
                text += `Customer No : ${proses.customer_no} \n`;
                text += `SKU : ${proses.buyer_sku_code} \n`;
                await createDigi(proses.ref_id, proses.customer_no, proses.buyer_sku_code, proses.message, proses.status, proses.rc, proses.buyer_last_saldo, proses.sn, proses.price, proses.tele, proses.wa);
            }
            ctx.reply(text);
            ctx.session = {};
            ctx.session.selectedBot = `Digiflazz`;
            ctx.scene.enter(SCENE_KEYS.CATEGORY);
        }
        if (BOT === 'TokoVoucher') {
            if (Number(pesan)) {
                if (ctx.session.listJenis[pesan - 1]) {
                    ctx.session.selectedProduct = ctx.session.listJenis[pesan - 1];
                    ctx.scene.enter(SCENE_KEYS.OPSI1);
                }
                else {
                    ctx.reply('Maaf, Pilihan Belum tersedia');
                }
            }
        }
    }
});
export default botMenu;
