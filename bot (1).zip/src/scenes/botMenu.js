import telegraf from "telegraf";
import SCENE_KEYS from "../constants/sceneKeys.js";
import { showKeyboardChunk } from "../function/keyboard.js";
const { Markup, Scenes } = telegraf;
const BOT_MENU = [
    "Digiflazz",
    "TokoVoucher",
];
const botMenu = new Scenes.BaseScene(SCENE_KEYS.BOT);
botMenu.enter((ctx) => {
    // console.log("Masukk Scene Bot")
    ctx.reply('Silahkan Pilih Bot', showKeyboardChunk(BOT_MENU));
});
botMenu.on('text', (ctx) => {
    const selectedBot = ctx.message.text;
    switch (selectedBot) {
        case 'Digiflazz':
            ctx.session.selectedBot = selectedBot;
            ctx.scene.enter(SCENE_KEYS.CATEGORY);
            break;
        case 'TokoVoucher':
            ctx.session.selectedBot = selectedBot;
            ctx.scene.enter(SCENE_KEYS.CATEGORY);
            break;
        default:
            ctx.reply('Maaf, Pilihan Belum tersedia');
            break;
    }
});
export default botMenu;
