import axios from "axios";
async function getDataFromAPI(noPelanggan) {
    // Data request
    const requestData = {
        commands: "pln-subscribe",
        customer_no: noPelanggan
    };
    // API endpoint
    const endpoint = "https://api.digiflazz.com/v1/transaction";
    try {
        // Make the Axios POST request
        const response = await axios.post(endpoint, requestData, {
            headers: {
                "Content-Type": "application/json"
            }
        });
        // Extract relevant information
        const data = response.data;
        if (data && data.data) {
            // console.log(data.data);
            return data.data;
            // Display the information
            console.log("Customer No: " + customer_no);
            console.log("Meter No: " + meter_no);
            console.log("Subscriber ID: " + subscriber_id);
            console.log("Name: " + name);
            console.log("Segment Power: " + segment_power);
        }
        else {
            // No data found
            console.log("No data found");
        }
    }
    catch (error) {
        console.error("An error occurred:", error.message);
    }
}
export default getDataFromAPI;
