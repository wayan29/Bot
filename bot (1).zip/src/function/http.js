import crypto from "crypto";
import axios from "axios";
import fs from "fs";
import { get } from "http";
import dotenv from "dotenv";
dotenv.config();
const getListProductDigi = async () => {
    const cacheFile = 'src/cache/digiflazz.json';
    const username = process.env.username;
    const apikey = process.env.apikey;
    const url = 'https://api.digiflazz.com';
    const endpoint = url + '/v1/price-list';
    const cmd = 'prepaid';
    const sign = crypto
        .createHash('md5')
        .update(username + apikey + 'pricelist')
        .digest('hex');
    try {
        let json;
        if (fs.existsSync(cacheFile)) {
            const data = {
                cmd: cmd,
                username: username,
                sign: sign,
            };
            const response = await axios.post(endpoint, data);
            json = response.data;
            fs.writeFileSync(cacheFile, JSON.stringify(json));
        }
        else {
            const data = {
                cmd: cmd,
                username: username,
                sign: sign,
            };
            const response = await axios.post(endpoint, data);
            json = response.data;
            fs.writeFileSync(cacheFile, JSON.stringify(json));
        }
        if (json.data) {
            const categories = Array.from(new Set(json.data.map(item => item.category)));
            // categories.push('Back');
            return categories;
        }
        else {
            return [];
        }
    }
    catch (error) {
        console.log(error);
        return [];
    }
};
// get list brand from digiflazz.json
// berikan parameter category
const getListBrand = async (category) => {
    const cacheFile = 'src/cache/digiflazz.json';
    try {
        let json;
        const data = fs.readFileSync(cacheFile);
        json = JSON.parse(data);
        // filter data by category
        json.data = json.data.filter(item => item.category === category);
        // get list brand
        const brands = Array.from(new Set(json.data.map(item => item.brand)));
        // brands.push('Back');
        return brands;
    }
    catch (error) {
        console.log(error);
        return [];
    }
};
const getProductList = async (category, brand) => {
    const cacheFile = 'src/cache/digiflazz.json';
    try {
        let json;
        const data = fs.readFileSync(cacheFile);
        json = JSON.parse(data);
        // filter data by category and brand
        json.data = json.data.filter(item => item.category === category && item.brand === brand);
        // console.log(json.data);
        // hitung berapa banyak json.data
        // const count = json.data.length;
        // console.log(count);
        // return product_name to list
        // const products = Array.from(new Set(json.data.map(item => item.product_name)));
        // const products = json.data.map(item => item.product_name);
        // console.log(json.data);
        // console.log(products.length);
        // products.push('Back');
        return json.data;
    }
    catch (error) {
        return [];
    }
};
getProductList('Pulsa', 'TELKOMSEL');
// run getProductList promise
// get price from digiflazz.json
// filter product_name
const getPrice = async (product_name) => {
    const cacheFile = 'src/cache/digiflazz.json';
    try {
        let json;
        const data = fs.readFileSync(cacheFile);
        json = JSON.parse(data);
        // filter data by product_name
        json.data = json.data.filter(item => item.product_name === product_name);
        // return all data to list
        return json.data;
    }
    catch (error) {
        return [];
    }
};
async function performTransaction(refId, buyerSkuCode, customerNumber) {
    const endpointTransaksi = 'https://api.digiflazz.com/v1/transaction';
    const username = process.env.username;
    const apiKey = process.env.apikey;
    const dataTransaksi = {
        ref_id: refId,
        username: username,
        buyer_sku_code: buyerSkuCode,
        customer_no: customerNumber,
        sign: crypto
            .createHash('md5')
            .update(username + apiKey + refId)
            .digest('hex')
    };
    try {
        const response = await axios.post(endpointTransaksi, dataTransaksi, {
            headers: { 'Content-Type': 'application/json' }
        });
        return response.data.data;
    }
    catch (error) {
        if (error.response) {
            // Respons dengan kode status yang tidak berhasil (misalnya 400)
            console.error('Status code:', error.response.status);
            console.error('Message:', error.response.data.data.message);
            return error.response.data.data;
        }
        else if (error.request) {
            // Tidak ada respons yang diterima
            console.error('No response received:', error.request);
        }
        else {
            // Terjadi kesalahan saat melakukan permintaan
            console.error('Error:', error.message);
        }
        return null;
    }
}
async function checkSaldoDigi() {
    const username = process.env.username;
    const apiKey = process.env.apikey;
    const url = "https://api.digiflazz.com";
    const endpointsal = url + '/v1/cek-saldo';
    const cmd1 = 'deposit';
    const sign = crypto
        .createHash('md5')
        .update(username + apiKey + 'depo')
        .digest('hex');
    const data = {
        'cmd': cmd1,
        'username': username,
        'sign': sign
    };
    try {
        // Make the request to the API
        const response = await axios.post(endpointsal, data, {
            headers: {
                'Content-Type': 'application/json'
            }
        });
        // Parse the JSON data from the response
        const json = response.data;
        if (json.data && json.data.deposit !== undefined) {
            const saldo = json.data.deposit;
            console.log('Saldo Anda adalah: Rp ' + numberWithCommas(saldo));
            return saldo;
        }
        else {
            throw new Error('Error: ' + json.message);
        }
    }
    catch (error) {
        console.error('Terjadi kesalahan:', error.message);
        throw error;
    }
}
// Helper function to format saldo with commas for thousands separator
function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}
export { getListProductDigi };
export { getListBrand };
export { getProductList };
export { getPrice };
export { performTransaction };
export { numberWithCommas };
export { checkSaldoDigi };
export default {
    getListProductDigi,
    getListBrand,
    getProductList,
    getPrice,
    performTransaction,
    numberWithCommas,
    checkSaldoDigi
};
