import { getListProductDigi } from "./http.js";
getListProductDigi().then((data) => {
    console.log(data);
});
