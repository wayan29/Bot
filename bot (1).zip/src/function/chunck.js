function chunkArray(arr, size) {
    const chunkedArr = [];
    index = 0;
    while (index < arr.length) {
        chunkedArr.push(arr.slice(index, index + size));
        index += size;
    }
    return chunkedArr;
}
export default chunkArray;
