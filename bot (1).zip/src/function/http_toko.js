import axios from "axios";
import dotenv from "dotenv";
dotenv.config();
const getKategori = async () => {
    // add member_code , signature
    const memberCode = process.env.member_code;
    const signature = process.env.signature;
    const url = `https://api.tokovoucher.id/member/produk/category/list?member_code=${memberCode}&signature=${signature}`;
    try {
        const response = await axios.get(url);
        const data = response.data.data;
        // const categories = {};
        // make object from data id and nama
        // di dalam object terdiri dari id dan nama    
        return data;
    }
    catch (error) {
        console.error('Error:', error);
        throw error;
    }
};
// find id by name
const findIdByName = async (name) => {
    const categories = await getKategori();
    const category = categories.find(category => category.nama == name);
    return category.id;
};
// get operator by category
const getOperatorByCategory = async (category) => {
    const memberCode = process.env.member_code;
    const signature = process.env.signature;
    const url = `https://api.tokovoucher.id/member/produk/operator/list?member_code=${memberCode}&signature=${signature}&id=${category}`;
    try {
        const response = await axios.get(url);
        const data = response.data.data;
        // const categories = {};
        return data;
    }
    catch (error) {
        console.error('Error:', error);
        throw error;
    }
};
// find id operator by name
const findIdOperatorByName = async (name, id_Category) => {
    const categories = await getOperatorByCategory(id_Category);
    // console.log(categories);
    const category = categories.find(category => category.nama == name);
    return category.id;
};
// findIdOperatorByName('Pulsa Telkomsel', 4).then(data => {
//     console.log(data);
// }).catch(error => {
//     console.error(error);
// });
const getJenis = async (id_Operator) => {
    const memberCode = process.env.member_code;
    const signature = process.env.signature;
    const url = `https://api.tokovoucher.id/member/produk/jenis/list?member_code=${memberCode}&signature=${signature}&id=${id_Operator}`;
    try {
        const response = await axios.get(url);
        const data = response.data.data;
        // const categories = {};
        return data;
    }
    catch (error) {
        console.error('Error:', error);
        throw error;
    }
};
// Find id jenis by name
const findIdJenisByName = async (name, id_Operator) => {
    const categories = await getJenis(id_Operator);
    // console.log(categories);
    const category = categories.find(category => category.nama == name);
    // console.log(category);
    return category.id;
};
const getListJenis = async (id_Operator) => {
    const memberCode = process.env.member_code;
    const signature = process.env.signature;
    const url = `https://api.tokovoucher.id/member/produk/list?member_code=${memberCode}&signature=${signature}&id_jenis=${id_Operator}`;
    try {
        const response = await axios.get(url);
        const data = response.data.data;
        // debug
        // console.log(data);
        // const categories = {};
        return data;
    }
    catch (error) {
        console.error('Error:', error);
        throw error;
    }
};
const findIdListJenisByName = async (name, id_Operator) => {
    const categories = await getListJenis(id_Operator);
    // categories.forEach(category => {
    //     console.log(category.nama_produk);
    // });
    const category = categories.find(category => category.nama_produk === name);
    // const category = categories.find(category => category.nama_produk == name);
    // console.log(category);
    return category.code;
};
//const getRefId = () => {
//  const ref_id = "REF" + Date.now() + "WAYAN";
//return ref_id;
//}
const getRefId = () => {
    const now = new Date();
    // Tambahkan 1 jam untuk mendapatkan waktu dalam zona waktu WITA
    now.setHours(now.getHours() + 1);
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const date = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    const ref_id = "REF" + year + month + date + hours + minutes + seconds + "WAYAN";
    return ref_id;
};
const createTrx = async (ref_id, produk, tujuan, server_id = "") => {
    const secret = process.env.secret;
    const member_code = process.env.member_code;
    const url = `https://api.tokovoucher.id/v1/transaksi?ref_id=${ref_id}&produk=${produk}&tujuan=${tujuan}&secret=${secret}&member_code=${member_code}&server_id=${server_id}`;
    try {
        const response = await axios.get(url);
        const data = response.data;
        return data;
    }
    catch (error) {
        console.error('Error:', error);
        throw error;
    }
};
async function checkSaldo() {
    const member_code = process.env.member_code;
    const signature = process.env.signature;
    const urlcek = `https://api.tokovoucher.id/member?member_code=${member_code}&signature=${signature}`;
    try {
        // Make the request to the API
        const response = await axios.get(urlcek);
        // Parse the JSON data from the response
        const data = response.data;
        if (data.status !== 1) {
            throw new Error(`Error !! : ${data.error_msg}`);
        }
        // // If successful, display member's name and saldo
        // console.log("Nama : ", data.data.nama);
        // console.log("Saldo : RP ", numberWithCommas(data.data.saldo));
        return data.data.saldo;
    }
    catch (error) {
        // If failed, display error message
        console.error(error.message);
    }
}
function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}
export { getKategori };
export { findIdByName };
export { getOperatorByCategory };
export { findIdOperatorByName };
export { getJenis };
export { findIdJenisByName };
export { getListJenis };
export { findIdListJenisByName };
export { getRefId };
export { createTrx };
export { checkSaldo };
export { numberWithCommas };
export default {
    getKategori,
    findIdByName,
    getOperatorByCategory,
    findIdOperatorByName,
    getJenis,
    findIdJenisByName,
    getListJenis,
    findIdListJenisByName,
    getRefId,
    createTrx,
    checkSaldo,
    numberWithCommas
};
