import digiDB, { checkDigi, getAllDigi, modifDigi } from "../models/trxdigi.js";
import axios from "axios";
import crypto from "crypto";
// const mongoose = require('mongoose');
// require('dotenv').config();
// const dbURL = process.env.MONGO_URL;
// mongoose.connect(dbURL, { useNewUrlParser: true, useUnifiedTopology: true })
//     .then(() => console.log('Connected to MongoDB'))
//     .catch((err) => console.error('Error connecting to MongoDB:', err));
async function checkTransactionStatus(RefID) {
    const username = process.env.username;
    const kunci = process.env.apikey;
    const endpoint = 'https://api.digiflazz.com/v1/transaction';
    // const ref_id = historyData[selected - 1];
    // find data by RefID from database
    const data = await checkDigi(RefID);
    if (!data) {
        // lempar eror pada error.response.data['data']
        throw new Error('Ref ID tidak ditemukan');
    }
    const ref_id_number = data.ref_id;
    const customer_no = data.customer_no;
    const buyer_sku_code = data.buyer_sku_code;
    // const ref_id_number = ref_id['ref_id'];
    // const customer_no = ref_id['customer_no'];
    // const buyer_sku_code = ref_id['buyer_sku_code'];
    const sign = crypto
        .createHash('md5')
        .update(username + kunci + ref_id_number)
        .digest('hex');
    const requestData = {
        username,
        buyer_sku_code,
        customer_no,
        ref_id: ref_id_number,
        sign,
    };
    // console.log(requestData);
    try {
        const requestDataJSON = JSON.stringify(requestData);
        const response = await axios.post(endpoint, requestDataJSON, {
            headers: {
                'Content-Type': 'application/json',
            },
        });
        const response_json = response.data;
        console.log(response_json);
        if (response_json.data.status === 'Sukses') {
            const result = {
                ref_id: response_json.data.ref_id,
                customer_no: response_json.data.customer_no,
                buyer_sku_code: response_json.data.buyer_sku_code,
                message: response_json.data.message,
                status: response_json.data.status,
                rc: response_json.data.rc,
                sn: response_json.data.sn,
                buyer_last_saldo: response_json.data.buyer_last_saldo,
                price: response_json.data.price,
                tele: response_json.data.tele,
                wa: response_json.data.wa,
            };
            return result;
        }
        else if (response_json.data.status === 'Pending') {
            const result = {
                ref_id: response_json.data.ref_id,
                customer_no: response_json.data.customer_no,
                buyer_sku_code: response_json.data.buyer_sku_code,
                message: response_json.data.message,
                status: response_json.data.status,
                rc: response_json.data.rc,
                sn: response_json.data.sn,
                buyer_last_saldo: response_json.data.buyer_last_saldo,
                price: response_json.data.price,
                tele: response_json.data.tele,
                wa: response_json.data.wa,
            };
            return result;
        }
        else if (response_json.data.status === 'Gagal') {
            const result = {
                message: response_json.data.message,
                status: response_json.data.status,
            };
            return result;
        }
        else {
            return "Gagal Terhubung Ke Server !";
        }
    }
    catch (error) {
        const response_json = error.response.data['data'];
        return response_json;
    }
}
const getAllDigiflazz = async (ctx, next) => {
    if (ctx.message.text.startsWith('/digi')) {
        const data = await getAllDigi();
        let no = 1;
        let messages = []; // Array untuk menyimpan semua pesan
        data.forEach((item) => {
            messages.push(`${no}. Ref ID : <code>${item.ref_id}</code>`);
            no++;
        });
        // Bagikan pesan menjadi beberapa bagian jika terlalu panjang
        const chunkSize = 25;
        for (let i = 0; i < messages.length; i += chunkSize) {
            const chunk = messages.slice(i, i + chunkSize).join('\n'); // Menggabungkan pesan dalam satu blok
            ctx.replyWithHTML(chunk); // Kirim pesan menggunakan ctx.replyWithHTML agar tetap urut
        }
    }
    else {
        next();
    }
};
// check digi
const checkDigiflazz = async (ctx, next) => {
    if (ctx.message.text.startsWith('/digicheck ')) {
        // Ambil nomor pelanggan setelah /digicheck
        const refIdNumber = ctx.message.text.slice(11).trim();
        try {
            const data = await checkTransactionStatus(refIdNumber);
            // jika data gagal maka kirim pesan error
            if (data.status === "Gagal") {
                ctx.reply("ERROR : " + data.message);
            }
            else {
                const message = `*Status Transaksi*: ${data.status}\n` +
                    `*SN*: ${data.sn}\n` +
                    `*Ref ID*: ${refIdNumber}\n`;
                ctx.reply(message, { parse_mode: 'Markdown' });
                // update database

                await modifDigi(refIdNumber, data.status, data.sn);
                // const updateTokoV = await DigiModels.findOneAndUpdate({ ref_id: refIdNumber }, {
                //     status: data.status,
                //     sn: data.sn,
                // }, { new: true });
            }
        }
        catch (error) {
            // jika data.error ada maka kirim pesan error
            if (error.response) {
                const response_json = error.response.data['data'];
                ctx.reply(response_json.message);
            }
            else {
                // ada yang salah dengan format pengiriman anda
                ctx.reply("Silahkan cek kembali format pengiriman anda");
            }
        }
    }
    else {
        next();
    }
};
export { getAllDigiflazz };
export { checkDigiflazz };
export default {
    getAllDigiflazz,
    checkDigiflazz
};
