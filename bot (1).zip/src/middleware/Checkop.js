function checkOperator(phoneNumber) {
    const telkomselPrefix = ["0811", "0812", "0813", "0821", "0822", "0823", "0852", "0853", "0851"];
    const indosatPrefix = ["0814", "0815", "0816", "0855", "0856", "0857", "0858"];
    const xlPrefix = ["0859", "0877", "0878", "0817", "0818", "0819"];
    const triPrefix = ["0898", "0899", "0895", "0896", "0897"];
    const smartfrenPrefix = ["0889", "0881", "0882", "0883", "0886", "0887", "0888", "0884", "0885"];
    const axisPrefix = ["0832", "0833", "0838", "0831"];
    const prefix = phoneNumber.substring(0, 4);
    if (telkomselPrefix.includes(prefix)) {
        return `Nomor HP ${phoneNumber} adalah Telkomsel`;
    }
    else if (indosatPrefix.includes(prefix)) {
        return `Nomor HP ${phoneNumber} adalah Indosat Ooredoo`;
    }
    else if (xlPrefix.includes(prefix)) {
        return `Nomor HP ${phoneNumber} adalah XL Axiata`;
    }
    else if (triPrefix.includes(prefix)) {
        return `Nomor HP ${phoneNumber} adalah 3 / Tri`;
    }
    else if (smartfrenPrefix.includes(prefix)) {
        return `Nomor HP ${phoneNumber} adalah Smartfren`;
    }
    else if (axisPrefix.includes(prefix)) {
        return `Nomor HP ${phoneNumber} adalah Axis`;
    }
    else {
        return `Tidak dapat mengenali operator dari nomor HP ${phoneNumber}`;
    }
}
const checkOp = (ctx, next) => {
    if (ctx.message.text.startsWith('/checkop ')) {
        const noHp = ctx.message.text.slice(8).trim();
        try {
            const data = checkOperator(noHp);
            ctx.reply(data);
        }
        catch (error) {
            ctx.reply('No HP tidak ditemukan atau terjadi kesalahan dalam mengambil data.');
        }
    }
    else {
        next();
    }
};
export default checkOp;
