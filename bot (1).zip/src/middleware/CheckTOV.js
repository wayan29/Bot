import axios from "axios";
import crypto from "crypto";
import tovDB, { modifTov, getAllTov } from "../models/tov.js";
async function checkTransactionStatus(refIdNumber) {
    const memberCode = process.env.member_code;
    const key = process.env.secret;
    // Generate signature
    const signature = crypto
        .createHash('md5')
        .update(`${memberCode}:${key}:${refIdNumber}`)
        .digest('hex');
    const url = `https://api.tokovoucher.id/v1/transaksi/status?ref_id=${refIdNumber}&member_code=${memberCode}&signature=${signature}`;
    try {
        const response = await axios.get(url);
        const data = response.data;
        if (data.status === 0) {
            throw new Error("Error accessing API: " + data.error_msg);
        }
        else if (data.status === "pending") {
            return data;
        }
        else if (data.status === "sukses") {
            return data;
        }
        else if (data.status === "gagal") {
            return data;
        }
        else {
            console.log("Status response tidak valid");
            return;
        }
    }
    catch (error) {
        return { error: error.message };
    }
}
// middleware untuk cek status transaksi
const checkStatus = async (ctx, next) => {
    await tovDB.read();
    if (ctx.message.text.startsWith('/tovcheck ')) {
        // Ambil nomor pelanggan setelah /tovcheck
        const refIdNumber = ctx.message.text.slice(10).trim();
        try {
            const data = await checkTransactionStatus(refIdNumber);
            // console.log("Status transaksi " + refIdNumber + " adalah SUKSES");
            // console.log("Status : " + data.status);
            // console.log("SN : " + data.sn);
            //   jika data.error ada maka kirim pesan error
            if (data.error) {
                ctx.reply(data.error);
            }
            else {
                const message = `*Status Transaksi*: ${data.status}\n` +
                    `*SN*: ${data.sn}\n` +
                    `*Ref ID*: ${refIdNumber}\n`;
                ctx.reply(message, { parse_mode: 'Markdown' });
                // update database
                await modifTov(refIdNumber, data.status, data.sn);
            }
        }
        catch (error) {
            ctx.reply(error);
            // console.error('Error checking transaction status:', error);
        }
    }
    else {
        next();
    }
};
const GetAll = async (ctx, next) => {
    if (ctx.message.text.startsWith('/tov')) {
        await tovDB.read();
        const data = getAllTov();
        let no = 1;
        let messages = []; // Array untuk menyimpan semua pesan
        data.forEach((item) => {
            messages.push(`${no}. Ref ID : <code>${item.ref_id}</code>`);
            no++;
        });
        // Bagikan pesan menjadi beberapa bagian jika terlalu panjang
        const chunkSize = 25;
        for (let i = 0; i < messages.length; i += chunkSize) {
            const chunk = messages.slice(i, i + chunkSize).join('\n'); // Menggabungkan pesan dalam satu blok
            ctx.replyWithHTML(chunk); // Kirim pesan menggunakan ctx.replyWithHTML agar tetap urut
        }
    }
    else {
        next();
    }
};
export { checkStatus };
export { GetAll };
export default {
    checkStatus,
    GetAll
};
