import axios from "axios";
import { createHash } from "crypto";
function fetchData() {
    const endpoint = "https://api.digiflazz.com/v1/transaction";
    const ref_id_number = "REF20230629183857WAYAN";
    const customer_no = "085796437311";
    const buyer_sku_code = "IS50";
    // Display the data with the appropriate variables
    console.log("Data Ref Id: " + ref_id_number);
    console.log("Customer Number: " + customer_no);
    console.log("Buyer SKU Code: " + buyer_sku_code);
    console.log();
    const sign = { createHash }.createHash('md5')
        .update("zowosaoBQaNg" + "dee805b0-f3c9-5a8a-a74f-8e07635b7912" + ref_id_number)
        .digest('hex');
    const data = {
        'username': "zowosaoBQaNg",
        'buyer_sku_code': buyer_sku_code,
        'customer_no': customer_no,
        'ref_id': ref_id_number,
        'sign': sign
    };
    axios.post(endpoint, data, {
        headers: {
            'Content-Type': 'application/json'
        }
    })
        .then(response => {
        const response_json = response.data;
        if (response_json['data']['status'] === 'Sukses' || response_json['data']['status'] === 'Pending') {
            console.log("Ref ID: " + response_json['data']['ref_id']);
            console.log("Customer No: " + response_json['data']['customer_no']);
            console.log("Buyer SKU Code: " + response_json['data']['buyer_sku_code']);
            console.log("Message: " + response_json['data']['message']);
            console.log("Status: " + response_json['data']['status']);
            console.log("RC: " + response_json['data']['rc']);
            console.log("SN: " + response_json['data']['sn']);
            console.log("Buyer Last Saldo: RP " + Number(response_json['data']['buyer_last_saldo']).toLocaleString('en-US'));
            console.log("Price: RP " + Number(response_json['data']['price']).toLocaleString('en-US'));
            console.log("Tele: " + response_json['data']['tele']);
            console.log("WA: " + response_json['data']['wa']);
        }
        else if (response_json['data']['status'] === 'Gagal') {
            console.log("Message: " + response_json['data']['message']);
            console.log("Status: " + response_json['data']['status']);
        }
        else {
            console.log("Gagal Terhubung Ke Server !");
        }
    })
        .catch(error => {
        // Check if there's a response from the server even if the request resulted in an error
        if (error.response) {
            const response_json = error.response.data;
            console.log("Error Response:");
            console.log("Ref ID: " + response_json['data']['ref_id']);
            console.log("Customer No: " + response_json['data']['customer_no']);
            console.log("Buyer SKU Code: " + response_json['data']['buyer_sku_code']);
            console.log("Message: " + response_json['data']['message']);
            console.log("Status: " + response_json['data']['status']);
            console.log("RC: " + response_json['data']['rc']);
        }
        else {
            console.error("Error:", error.message);
        }
    });
}
// Example usage:
fetchData();
